package Combyne;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class ForgotPasswordPage extends InvokeBrowser{

	public WebDriver driver;
	
	// I have defined all the webelements here for forgot password page
	By ForgotPasswordEmail = By.xpath("//*[@id=\"ui\"]/div/div[1]/div/div/form/div[4]/div/div[1]/fieldset/input");
	By Submit = By.xpath("//*[@id=\"ui\"]/div/div[1]/div/div/form/div[5]/input");
	
	// Created constructor for driver
	public ForgotPasswordPage(WebDriver driver)
	{
		this.driver=driver;
	}
	
	//Created method for all above defined webelements to use them in the project
	public WebElement ForgotPasswordEmail() 
	{
		return driver.findElement(ForgotPasswordEmail);
	}
	public WebElement Submit() 
	{
		return driver.findElement(ForgotPasswordEmail);
	}
}
