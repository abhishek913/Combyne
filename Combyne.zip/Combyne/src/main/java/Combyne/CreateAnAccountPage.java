package Combyne;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class CreateAnAccountPage extends InvokeBrowser {

	public WebDriver driver;
	
	// I have defined all the web elements here for Create an account page
	By FirstName=By.xpath("//*[@id=\"ui\"]/div/div[1]/form/div/div[3]/div[1]/div/div[1]/fieldset/div/input");
	By LastName=By.xpath("//*[@id=\"ui\"]/div/div[1]/form/div/div[3]/div[2]/div/div[1]/fieldset/div/input");
	By EmailAddress=By.xpath("//*[@id=\"ui\"]/div/div[1]/form/div/div[3]/div[3]/div/div[1]/fieldset/div/input");
	By Next = By.xpath("//*[@id=\"ui\"]/div/div[1]/form/div/div[5]/input");
	By ForgotPassword=By.xpath("//*[@id=\"ui\"]/div/div[1]/form/div/div[6]");
	By CreateAccount=By.xpath("//*[@id=\"ui\"]/div/div[1]/form/div/div[7]/span");
	By ContactUs=By.xpath("//*[@id=\"ui\"]/div/div[1]/form/div/div[8]/div/div[2]/a");
	
	// Created constructor for driver
	public CreateAnAccountPage(WebDriver driver)
	{
		this.driver=driver;
	}
	
	//Created method for all above defined webelements to use them in the project
	public WebElement FirstName() 
	{
		return driver.findElement(FirstName);
	}
	public WebElement LastName() 
	{
		return driver.findElement(LastName);
	}
	public WebElement EmailAddress() 
	{
		return driver.findElement(EmailAddress);
	}
	public WebElement Next() 
	{
		return driver.findElement(Next);
	}
	
}
