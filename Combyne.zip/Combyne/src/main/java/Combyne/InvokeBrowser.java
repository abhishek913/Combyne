package Combyne;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class InvokeBrowser {

	public WebDriver driver;
	public Properties prop;

	public WebDriver browserInitialization() throws IOException {

		prop = new Properties();

		// Read data.properties file
		FileInputStream file = new FileInputStream("C:\\Users\\Admin\\eclipse-workspace\\Google\\src\\main\\java\\Login\\Google\\data.properties");
		prop.load(file);
		String browser = prop.getProperty("browser");
		
		if (browser.equals("chrome")) {
			System.setProperty("webdriver.chrome.driver", "C:\\Users\\Admin\\Desktop\\chromedriver.exe");
			driver = new ChromeDriver();
		} else if (browser.equals("firefox")) {
			// Here I can set property to firefox and initialize firefox
		} else if (browser.equals("IE")) {
			// Here I can set property to IE and initialize IE
		}
		return driver;

	}
}
