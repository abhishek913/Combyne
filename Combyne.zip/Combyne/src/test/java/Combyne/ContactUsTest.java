package Combyne;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class ContactUsTest extends InvokeBrowser {

	public WebDriver driver;

	@BeforeTest
	public void initialize() throws IOException {

		driver = browserInitialization();
	}

	@Test

	public void ContactUs() {

		driver.get(prop.getProperty("url"));
		LoginPage lp = new LoginPage(driver);

		// Click on contact us to send email
		lp.ContactUs().click();

	}

}
