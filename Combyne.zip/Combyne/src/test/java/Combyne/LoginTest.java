package Combyne;

import static org.testng.Assert.assertTrue;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class LoginTest extends InvokeBrowser {

	public WebDriver driver;

	@BeforeTest
	public void initialize() throws IOException {

		driver = browserInitialization();
	}

	@Test(dataProvider = "getData")

	public void LoginCheck(String getEmail, String password) {

		driver.get(prop.getProperty("url"));
		LoginPage lp = new LoginPage(driver);

		// Input email address in input field
		lp.getEmail().sendKeys(getEmail);

		// Input password in input field
		lp.password().sendKeys(password);

		// Clicking on Next to Signin
		lp.Next().click();
		
		//Added assertion to confirm wether credentials are valid or not
		/* Once we have valid credentials for once we can grab web element from the home page and add assertion to 
		 * confirm login by using assertion and isDisplayed 
		 */
		Assert.assertFalse(true, "Whoops! That email is not associated with an account.");

	}

	@AfterTest
	public void Close() throws IOException {
		driver.close();
	}

		// Leveraged DataProvider annotation of Testng to test different dataset of credentials
	@DataProvider
	public Object[][] getData() {

		Object[][] data = new Object[2][2];
		
		//First dataset of credentials
		data[0][0] = "";
		data[0][1] = "";

		//Second dataset of credentials
		data[1][0] = "";
		data[1][1] = "";

		return data;
	}

}
