package Combyne;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class CreateAnAccountTest extends InvokeBrowser {

	public WebDriver driver;

	@BeforeTest
	public void initialize() throws IOException {

		driver = browserInitialization();
	}

	@Test(dataProvider = "getData1")

	public void ContactUs(String FirstName, String LastName, String EmailAddress) {

		driver.get(prop.getProperty("url"));
		LoginPage lp = new LoginPage(driver);
		//Click on Create account 
		lp.CreateAccount().click();
		
		// Created object of CreateAnAccountPage to leverage them here
		CreateAnAccountPage caap = new CreateAnAccountPage(driver);
		
		// Input First name
		caap.FirstName().sendKeys(FirstName);
		
		// Input Last name
		caap.LastName().sendKeys(LastName);
		
		// Input email address

		caap.EmailAddress().sendKeys(EmailAddress);
		
		//Click on next button to create account
		caap.Next().click();

	}
	
	// Leveraged DataProvider annotation of Testng to test different dataset of credentials
	@DataProvider
	public Object[][] getData1() {

		Object[][] data = new Object[1][3];

		// Dataset of credentials
		data[0][0] = "";
		data[0][1] = "";
		data[0][2] = "";

		return data;
	}

}
