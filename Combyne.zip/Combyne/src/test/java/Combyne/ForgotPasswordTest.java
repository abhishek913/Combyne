package Combyne;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class ForgotPasswordTest extends InvokeBrowser {

	public WebDriver driver;

	@BeforeTest
	public void initialize() throws IOException {

		driver = browserInitialization();
	}

	@Test(dataProvider = "getData")

	public void ForgotPassword(String ForgotPasswordEmail) {

		driver.get(prop.getProperty("url"));
		ForgotPasswordPage fpp = new ForgotPasswordPage(driver);
		LoginPage lp = new LoginPage(driver);

		// Click on Forgot Password to reset Password
		lp.ForgotPassword().click();

		// Input email address to reset password
		fpp.ForgotPasswordEmail().sendKeys(ForgotPasswordEmail);
		
		// Click submit to reset password
		fpp.Submit().click();

	}

	@AfterTest
	public void Close() throws IOException {
		driver.close();
	}

	// Leveraged DataProvider annotation of Testng to test different dataset of credentialss
	
	@DataProvider
	public Object[][] getData() {

		Object[][] data = new Object[2][1];

		data[0][0] = "";

		data[1][0] = "";

		return data;
	}

}
